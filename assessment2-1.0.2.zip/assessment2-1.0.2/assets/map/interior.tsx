<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="interior" tilewidth="16" tileheight="16" tilecount="9035" columns="139">
 <image source="interior/interior.png" width="2224" height="1040"/>
 <tile id="603">
  <animation>
   <frame tileid="603" duration="200"/>
   <frame tileid="604" duration="200"/>
   <frame tileid="605" duration="200"/>
   <frame tileid="606" duration="200"/>
   <frame tileid="607" duration="200"/>
   <frame tileid="608" duration="200"/>
  </animation>
 </tile>
 <tile id="3622">
  <animation>
   <frame tileid="3622" duration="250"/>
   <frame tileid="3624" duration="250"/>
   <frame tileid="3626" duration="250"/>
   <frame tileid="3628" duration="250"/>
   <frame tileid="3630" duration="250"/>
   <frame tileid="3632" duration="250"/>
   <frame tileid="3634" duration="250"/>
   <frame tileid="3636" duration="250"/>
   <frame tileid="3638" duration="250"/>
   <frame tileid="3640" duration="250"/>
   <frame tileid="3642" duration="250"/>
   <frame tileid="3644" duration="250"/>
  </animation>
 </tile>
 <tile id="3623">
  <animation>
   <frame tileid="3623" duration="250"/>
   <frame tileid="3625" duration="250"/>
   <frame tileid="3627" duration="250"/>
   <frame tileid="3629" duration="250"/>
   <frame tileid="3631" duration="250"/>
   <frame tileid="3633" duration="250"/>
   <frame tileid="3635" duration="250"/>
   <frame tileid="3637" duration="250"/>
   <frame tileid="3639" duration="250"/>
   <frame tileid="3641" duration="250"/>
   <frame tileid="3643" duration="250"/>
   <frame tileid="3645" duration="250"/>
  </animation>
 </tile>
 <tile id="3761">
  <animation>
   <frame tileid="3761" duration="250"/>
   <frame tileid="3763" duration="250"/>
   <frame tileid="3765" duration="250"/>
   <frame tileid="3767" duration="250"/>
   <frame tileid="3769" duration="250"/>
   <frame tileid="3771" duration="250"/>
   <frame tileid="3773" duration="250"/>
   <frame tileid="3775" duration="250"/>
   <frame tileid="3777" duration="250"/>
   <frame tileid="3779" duration="250"/>
   <frame tileid="3781" duration="250"/>
   <frame tileid="3783" duration="250"/>
  </animation>
 </tile>
 <tile id="3762">
  <animation>
   <frame tileid="3762" duration="250"/>
   <frame tileid="3764" duration="250"/>
   <frame tileid="3766" duration="250"/>
   <frame tileid="3768" duration="250"/>
   <frame tileid="3770" duration="250"/>
   <frame tileid="3772" duration="250"/>
   <frame tileid="3774" duration="250"/>
   <frame tileid="3776" duration="250"/>
   <frame tileid="3778" duration="250"/>
   <frame tileid="3780" duration="250"/>
   <frame tileid="3782" duration="250"/>
   <frame tileid="3784" duration="250"/>
  </animation>
 </tile>
</tileset>
