<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="buildings" tilewidth="16" tileheight="16" tilecount="5472" columns="72">
 <image source="buildings/buildings_all.png" width="1152" height="1216"/>
</tileset>
