<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bird_common_black_animations" tilewidth="16" tileheight="16" tilecount="32" columns="4">
 <image source="animals/bird_common_black_animations.png" width="64" height="128"/>
 <tile id="5">
  <animation>
   <frame tileid="5" duration="200"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="5" duration="150"/>
   <frame tileid="6" duration="150"/>
   <frame tileid="5" duration="200"/>
   <frame tileid="4" duration="2000"/>
  </animation>
 </tile>
</tileset>
