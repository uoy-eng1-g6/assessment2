# ENG1 Project

## Website
<https://uoy-eng1-g6.github.io/assessment2/>

## Contributors
(Assessment 1)
- [Liam](https://github.com/TheRealEmissions)
- [Lucy](https://github.com/lc2353)
- [Tim](https://github.com/tgorst)
- [Sammy](https://github.com/sammyhori)
- [Zac](https://github.com/Zr695)
- [Kai]()
- [Lia]()

(Assessment 2)
- [Oliver C](https://github.com/KEKEK375)
- [Cooper](https://github.com/cooperjl)
- [Anna](https://github.com/satesilka)
- [Mikolaj](https://github.com/SlimJunky)
- [Oliver T](https://github.com/tandemdude)
- [Freya](https://github.com/red-fisher14)
- [Barnaby](https://github.com/barnaby-matthews)

## Let Ron Cooke
Let Ron Cooke is a single-player student simulator, where the player controls Ron, and takes him through a week at University. Will he survive? Will he pass his exams? Will he get alcohol poisoning? Who knows!

## How to Play
Movement is achieved using `WASD` or the arrow keys.

You can speed up the character using `CTRL`.

Activities can be interacted with using `E`.

There are a few hidden activities around, can you find them?

## Score

In the current iteration of the game the score and associated grade is printed to terminal.
